# HarborFlowSuite Client

This project contains the client-side Blazor application for HarborFlowSuite.

## Map Layer Thumbnails

The map layer selector UI uses thumbnail images for each map layer. These images are expected to be in the `wwwroot/images` directory.

Please provide the following images:

- `wwwroot/images/street-thumbnail.png` (for the street map layer)
- `wwwroot/images/satellite-thumbnail.png` (for the satellite map layer)
- `wwwroot/images/nasa-thumbnail.png` (for the NASA Blue Marble layer)
- `wwwroot/images/sea-temp-thumbnail.png` (for the Sea Surface Temperature layer)
- `wwwroot/images/copernicus-thumbnail.png` (for the Copernicus layer)

These images should be 48x48 pixels.

## Copernicus Layer Configuration

The Copernicus map layer requires manual configuration to work. You need to obtain a WMS Instance ID from the Copernicus Data Space Ecosystem.

1.  Go to the [Copernicus Data Space Ecosystem](https://dataspace.copernicus.eu/).
2.  Create a configuration for the layers you wish to visualize. This process will generate an "Instance ID".
3.  Once you have your Instance ID, open `HarborFlowSuite/HarborFlowSuite.Client/Components/MapLayerSelector.razor`.
4.  Find the `availableLayers` list and update the "Copernicus" `MapLayer` object:
    -   Replace the placeholder in the `TileUrl` with your WMS URL including your instance ID (e.g., `https://sh.dataspace.copernicus.eu/ogc/wms/<YOUR_INSTANCE_ID>`).
    -   You will also need to specify the `layers` parameter in the WMS URL.
    -   Set `IsDisabled` to `false`.

Example:
```csharp
new MapLayer { Name = "Copernicus", ThumbnailUrl = "images/copernicus-thumbnail.png", TileUrl = "https://sh.dataspace.copernicus.eu/ogc/wms/<YOUR_INSTANCE_ID>?layers=<YOUR_LAYER_ID>", IsDisabled = false }
```
