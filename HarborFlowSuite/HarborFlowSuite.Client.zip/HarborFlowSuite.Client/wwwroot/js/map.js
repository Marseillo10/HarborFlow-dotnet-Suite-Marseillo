window.HarborFlowMap = {
    map: null,
    vesselMarkers: {}, // Object to store markers by MMSI
    tileLayer: null,
    dotNetHelper: null,
    debounceTimer: null,

    debounce: function (func, delay) {
        return (...args) => {
            clearTimeout(this.debounceTimer);
            this.debounceTimer = setTimeout(() => func.apply(this, args), delay);
        };
    },

    initMap: function (elementId = 'map', dotNetHelper, initialLayerUrl, initialLayerAttribution) {
        if (this.map) {
            this.map.remove();
        }
        this.dotNetHelper = dotNetHelper;
        const mapElement = document.getElementById(elementId);
        if (!mapElement) {
            console.error(`Map element with id '${elementId}' not found.`);
            return;
        }
        this.map = L.map(mapElement).setView([1.352083, 103.819836], 12); // Centered on Singapore

        this.tileLayer = L.tileLayer(initialLayerUrl, {
            attribution: initialLayerAttribution
        }).addTo(this.map);

        const resizeObserver = new ResizeObserver(() => {
            this.invalidateMapSize();
        });
        resizeObserver.observe(mapElement);
    },

    switchLayer: function (layerUrl, attribution) {
        if (this.map && this.tileLayer) {
            this.tileLayer.setUrl(layerUrl);
            this.tileLayer.options.attribution = attribution;
            this.tileLayer.redraw();
        }
    },

    addVesselMarkers: function (vesselPositions) {
        if (this.map && vesselPositions) {
            vesselPositions.forEach(position => {
                this.updateVesselMarker(
                    position.vesselId.toString(),
                    position.latitude,
                    position.longitude,
                    position.heading,
                    position.speed,
                    position.vesselName,
                    position.vesselType,
                    position.metadata
                );
            });
            this.updateTotalVesselCount();
        }
    },

    updateVesselMarker: function (mmsi, lat, lng, heading, speed, name, type = 'HSC', metadata) {
        if (!this.map) return;

        const iconUrl = this.getIconUrl(type);
        const vesselIcon = L.divIcon({
            className: 'custom-vessel-icon',
            html: `<img src="${iconUrl}" style="transform: rotate(${heading}deg); width: 48px; height: 48px;" />`,
            iconSize: [48, 48],
            iconAnchor: [24, 24],
            popupAnchor: [0, -24]
        });

        let popupContent = `<b>Vessel:</b> ${name}<br>
                              <b>Type:</b> ${type}<br>
                              <b>Lat:</b> ${lat}<br>
                              <b>Lng:</b> ${lng}<br>
                              <b>Speed:</b> ${speed} knots<br>
                              <b>Heading:</b> ${heading}°`;

        if (this.vesselMarkers[mmsi]) {
            // Update existing marker
            this.vesselMarkers[mmsi].setLatLng([lat, lng]);
            this.vesselMarkers[mmsi].setIcon(vesselIcon);
            this.vesselMarkers[mmsi].setPopupContent(popupContent);
        } else {
            // Create new marker
            const newMarker = L.marker([lat, lng], { icon: vesselIcon }).addTo(this.map);
            newMarker.bindPopup(popupContent);
            newMarker.on('click', () => {
                this.dotNetHelper.invokeMethodAsync('VesselSelected', mmsi);
            });
            this.vesselMarkers[mmsi] = newMarker;
        }
        this.updateTotalVesselCount();
    },

    getIconUrl: function (vesselType) {
        let type = vesselType ? vesselType.toLowerCase() : 'other';
        switch (type) {
            case 'cargo':
                return '/images/vessels/cargo.png';
            case 'tanker':
                return '/images/vessels/tanker.png';
            case 'passenger':
                return '/images/vessels/passenger.png';
            case 'fishing':
                return '/images/vessels/fishing.png';
            case 'hsc':
                return '/images/vessels/hsc.png';
            case 'tug':
                return '/images/vessels/tug.png';
            case 'sailing':
                return '/images/vessels/sailing.png';
            default:
                return '/images/vessels/other.png';
        }
    },

    invalidateMapSize: function () {
        if (this.map) {
            this.map.invalidateSize();
        }
    },

    updateTotalVesselCount: function () {
        if (!this.dotNetHelper) return;

        const totalCount = Object.keys(this.vesselMarkers).length;
        this.dotNetHelper.invokeMethodAsync('UpdateVisibleVesselCount', totalCount);
    },

    updateVesselMetadata: function (mmsi, metadata) {
        if (!this.map || !this.vesselMarkers[mmsi] || !metadata) return;

        const marker = this.vesselMarkers[mmsi];
        let popupContent = marker.getPopup().getContent();

        popupContent += `<br><b>Flag:</b> ${metadata.flag}<br>
                             <b>Length:</b> ${metadata.length}m<br>
                             <b>IMO:</b> ${metadata.imoNumber}`;

        marker.setPopupContent(popupContent);
    }
};
